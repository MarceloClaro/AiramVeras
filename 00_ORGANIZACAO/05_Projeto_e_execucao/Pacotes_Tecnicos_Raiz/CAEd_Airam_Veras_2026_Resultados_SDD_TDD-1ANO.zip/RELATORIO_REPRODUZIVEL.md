# RELATÓRIO REPRODUTÍVEL — ESCOLA AIRAM VERAS (2026)
Análise exploratória de Língua Portuguesa; não usar como resultado oficial de Matemática.

## 1º ano
- Avaliados: 24; adequados: 10 (41.7%).
- Alvo: 20/24; faltam 10 conversões; mínimo de 20 acertos adicionais no grupo-alvo.
- Corte empírico da contraprova: 17/22 (não confundir com regra oficial).
- Pares: 24; r de Pearson=0.107 (p=0.6173); McNemar exato p=0.3877.
- Códigos H para investigar primeiro pelo grupo-alvo: H04, H05, H07.

## 2º ano
- Avaliados: 28; adequados: 18 (64.3%).
- Alvo: 23/28; faltam 5 conversões; mínimo de 15 acertos adicionais no grupo-alvo.
- Corte empírico da contraprova: 16/22 (não confundir com regra oficial).
- Pares: 25; r de Pearson=0.586 (p=0.0021); McNemar exato p=0.7266.
- Códigos H para investigar primeiro pelo grupo-alvo: H01, H07, H08.

## Limitações de validade
Correlação não é causalidade. Instrumentos sem equacionamento confirmado.
Projeções são cenários hipotéticos e não modelos calibrados. Confirmar descritores H na matriz oficial.
Checar três respostas zeradas no 2º ano, sem inferir suas causas.
