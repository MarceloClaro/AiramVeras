#!/usr/bin/env python3
"""Reconstrói tabelas de auditoria CAEd a partir dos 4 ZIPs exportados.
Sem dependências externas para CSV/JSON. Uso:
python gerar_dataset_caed_airam_veras.py --input-dir /mnt/data --out-dir /mnt/data/dataset_CAEd
Aplicações 'referencia' e 'contraprova' são rótulos analíticos assumidos,
NÃO definidos nos CSVs CAEd; horários no nome são exportação e não data da prova.
"""
from __future__ import annotations
import argparse,csv,io,math,statistics,json,re,unicodedata,zipfile
from collections import Counter,defaultdict
from pathlib import Path

ZIP_NAMES = {
  ('1º ano','referencia'): 'CAEd_DadosExportados.zip',
  ('1º ano','contraprova'): 'CAEd_DadosExportados (3).zip',
  ('2º ano','referencia'): 'CAEd_DadosExportados (1).zip',
  ('2º ano','contraprova'): 'CAEd_DadosExportados (2).zip',
}

def read_csv_bytes(b):
    return list(csv.DictReader(io.StringIO(b.decode('utf-8-sig')), delimiter=';'))

def simple_name(x):
    return ' '.join(x.replace('\xa0',' ').upper().split())

def write_csv(p,rows,headers):
    with open(p,'w',newline='',encoding='utf-8-sig') as fp:
        wr=csv.DictWriter(fp,fieldnames=headers,delimiter=';',extrasaction='ignore')
        wr.writeheader();wr.writerows(rows)

def safe_corr(xs,ys):
    if len(xs)<3:return None
    vx=sum((v-statistics.mean(xs))**2 for v in xs)
    vy=sum((v-statistics.mean(ys))**2 for v in ys)
    if vx==0 or vy==0:return None
    return sum((a-statistics.mean(xs))*(b-statistics.mean(ys)) for a,b in zip(xs,ys))/math.sqrt(vx*vy)

def run(indir,outdir):
    indir,outdir=Path(indir),Path(outdir)
    outdir.mkdir(exist_ok=True,parents=True)
    records=[]; responses=[]; school=[];turmas=[];paths={}; all_names=defaultdict(set)
    for (ano,prova),zip_name in ZIP_NAMES.items():
        with zipfile.ZipFile(indir/zip_name) as z:
            names=z.namelist()
            p0=next(n for n in names if n.startswith('HABILIDADES_DESEMPENHO_ESTUDANTE'))
            p1=next(n for n in names if n.startswith('HABILIDADE_DESEMPENHO_ESCOLA'))
            p2=next(n for n in names if n.startswith('HABILIDADE_DESEMPENHO_TURMA'))
            rows=read_csv_bytes(z.read(p0))
            off=read_csv_bytes(z.read(p1))[0]
            turma0=read_csv_bytes(z.read(p2))[0]
            paths[(ano,prova)]={'zip':zip_name,'student_csv':p0,'school_csv':p1,'turma_csv':p2}
            hs=sorted((f for f in rows[0] if re.fullmatch(r'H \d+',f)),key=lambda s:int(s[2:]))
            for item in rows:
                nome=simple_name(item['Estudante']); all_names[ano].add(nome)
                pairs=[]; tot_a=tot_n=0
                for h in hs:
                    a,n=map(int,re.findall(r'\d+',item[h])); tot_a+=a;tot_n+=n; pairs.append((h,a,n))
                records.append({'ano':ano,'aplicacao':prova,'nome':nome,'turma':item['Turma'],
                  'codigo_turma':item['Código da Turma'].strip(),'avaliado':item['Avaliado'],
                  'nivel_caed':item['Nível de aprendizagem'], 'acertos':tot_a,'itens':tot_n,
                  'taxa_acertos':tot_a/tot_n if tot_n else None,'adequado_caed':int(item['Nível de aprendizagem']=='Adequado'),
                  'arquivo_zip':zip_name,'arquivo_origem':p0, 'habilidades':pairs})
            sch={'ano':ano,'aplicacao':prova,'n_avaliados_pct_oficial':off['Avaliados (%)'],
               'defasagem_pct_oficial':off['Defasagem'].replace('%',''),
               'intermediario_pct_oficial':off['Aprendizado intermediário'].replace('%',''),
               'adequado_pct_oficial':off['Aprendizado adequado'].replace('%',''),
               'arquivo_zip':zip_name,'arquivo_origem':p1}
            school.append(sch)
            turma_row={'ano':ano,'aplicacao':prova,'turma':turma0['Turma'],'codigo_turma':turma0['Código da Turma'].strip(),
              'adequado_pct_oficial':turma0['Aprendizado adequado'].replace('%',''),
              'defasagem_pct_oficial':turma0['Defasagem'].replace('%',''),
              'intermediario_pct_oficial':turma0['Aprendizado intermediário'].replace('%',''),
              'arquivo_zip':zip_name,'arquivo_origem':p2}
            turmas.append(turma_row)
    ids={(ano,n): f"{ano[0]}A{i:03d}" for ano,names in all_names.items() for i,n in enumerate(sorted(names),1)}
    cuts={}
    for key in ZIP_NAMES:
        x=[r['acertos'] for r in records if (r['ano'],r['aplicacao'])==key and r['adequado_caed']==1]
        cuts[key]=min(x) if x else None # NOT published thresholds
    for rec in records:
        ano,prova=rec['ano'],rec['aplicacao']
        rec['id_aluno']=ids[(ano,rec['nome'])]
        rec['corte_observado']=cuts[(ano,prova)]
        rec['faltam_acertos_corte']=max(0,rec['corte_observado']-rec['acertos'])
        for h,a,n in rec['habilidades']:
            responses.append({'id_aluno':rec['id_aluno'],'ano':ano,'aplicacao':prova,'habilidade':h.replace(' ',''),
              'acertos':a,'itens':n,'erros':n-a,'percentual_acerto':a/n if n else '',
              'nivel_caed':rec['nivel_caed'],'adequado_caed':rec['adequado_caed'],
              'arquivo_zip':rec['arquivo_zip'],'arquivo_origem':rec['arquivo_origem']})
    records.sort(key=lambda r:(r['ano'],r['id_aluno'],0 if r['aplicacao']=='referencia' else 1))
    responses.sort(key=lambda r:(r['ano'],r['id_aluno'],r['aplicacao'],int(r['habilidade'][1:])))
    student_keys=['id_aluno','nome','ano','turma','codigo_turma','aplicacao','avaliado','nivel_caed','acertos','itens','taxa_acertos','adequado_caed','corte_observado','faltam_acertos_corte','arquivo_zip','arquivo_origem']
    write_csv(outdir/'01_alunos_avaliacoes_RESTRITO.csv',records,student_keys)
    write_csv(outdir/'01_alunos_avaliacoes_ANONIMO.csv',records,[k for k in student_keys if k!='nome'])
    write_csv(outdir/'02_respostas_habilidades_ANONIMO.csv',responses,
      ['id_aluno','ano','aplicacao','habilidade','acertos','itens','erros','percentual_acerto','nivel_caed','adequado_caed','arquivo_zip','arquivo_origem'])
    write_csv(outdir/'03_indicadores_oficiais_escola.csv',school,
       ['ano','aplicacao','n_avaliados_pct_oficial','defasagem_pct_oficial','intermediario_pct_oficial','adequado_pct_oficial','arquivo_zip','arquivo_origem'])
    write_csv(outdir/'04_indicadores_oficiais_turma.csv',turmas,
       ['ano','aplicacao','turma','codigo_turma','adequado_pct_oficial','defasagem_pct_oficial','intermediario_pct_oficial','arquivo_zip','arquivo_origem'])
    # Merging on stable exact normalized name, NOT row position.
    bykey={(r['ano'],r['aplicacao'],r['id_aluno']):r for r in records}
    pairs=[];pairs_named=[]; correlation=[]; metas=[]; cenarios=[]; audit=[]
    for ano in ('1º ano','2º ano'):
        idsref={r['id_aluno'] for r in records if r['ano']==ano and r['aplicacao']=='referencia'}
        idscon={r['id_aluno'] for r in records if r['ano']==ano and r['aplicacao']=='contraprova'}
        for id0 in sorted(idsref & idscon):
            ref=bykey[(ano,'referencia',id0)]; con=bykey[(ano,'contraprova',id0)]
            d={'id_aluno':id0,'ano':ano,'acertos_ref':ref['acertos'],'total_itens_ref':ref['itens'],
             'adequado_ref':ref['adequado_caed'],'nivel_ref':ref['nivel_caed'],
             'acertos_contra':con['acertos'],'total_itens_contra':con['itens'],
             'adequado_contra':con['adequado_caed'],'nivel_contra':con['nivel_caed'],
             'delta_acertos':con['acertos']-ref['acertos'],'delta_adequado':con['adequado_caed']-ref['adequado_caed']}
            pairs.append(d)
            pairs_named.append({'id_aluno':id0,'nome':con['nome'],**d})
        group=[r for r in records if r['ano']==ano and r['aplicacao']=='contraprova']
        num=len(group); n_adeq=sum(r['adequado_caed'] for r in group); target=math.ceil(0.8*num)
        to_convert=max(0,target-n_adeq)
        not_a=sorted([r for r in group if not r['adequado_caed']],key=lambda r:(r['faltam_acertos_corte'],r['id_aluno']))
        min_improvements=sum(r['faltam_acertos_corte'] for r in not_a[:to_convert])
        metas.append({'ano':ano,'n_contraprova':num,'n_adequados':n_adeq,
          'pct_adequados':n_adeq/num,'alvo_pct':0.80,'alvo_n_arredondado_cima':target,
          'conversoes_para_alvo':to_convert,'corte_empirico_contra':cuts[(ano,'contraprova')],
          'soma_lacunas_minima_grupo_prioritario':min_improvements,
          'nota':'Simulação aritmética condicional; não é previsão calibrada de aprendizagem.'})
        for d in range(0,7):
            hypothetic=sum(r['acertos']+d>=cuts[(ano,'contraprova')] for r in group)
            cenarios.append({'ano':ano,'ganho_hipotetico_acertos_por_aluno':d,'adequados_simulados':hypothetic,
               'pct_simulado':hypothetic/num,'alvo_80_alcancado':int(hypothetic>=target),
               'tipo':'Cenário determinístico; NÃO probabilidade nem previsão estatística calibrada'})
        grouped=[p for p in pairs if p['ano']==ano]
        xx=[x['acertos_ref'] for x in grouped]; yy=[x['acertos_contra'] for x in grouped]
        correlation.append({'ano':ano,'n_pares':len(grouped),'pearson_acertos_ref_contra':safe_corr(xx,yy),
               'descricao':'Correlação entre duas formas distintas de avaliação, sem implicar causa nem equivalência de Hxx.'})
        audit.append({'ano':ano,'n_referencia':len(idsref),'n_contraprova':len(idscon),'n_pareados':len(idsref&idscon),
                      'so_referencia':len(idsref-idscon),'so_contraprova':len(idscon-idsref),
                      'nomes_duplicados':0})
    write_csv(outdir/'05_pares_CONTRAPROVA_ANONIMO.csv',pairs,
       ['id_aluno','ano','acertos_ref','total_itens_ref','adequado_ref','nivel_ref',
        'acertos_contra','total_itens_contra','adequado_contra','nivel_contra','delta_acertos','delta_adequado'])
    write_csv(outdir/'05_pares_CONTRAPROVA_RESTRITO.csv',pairs_named,
       ['id_aluno','nome','ano','acertos_ref','total_itens_ref','adequado_ref','nivel_ref',
        'acertos_contra','total_itens_contra','adequado_contra','nivel_contra','delta_acertos','delta_adequado'])
    write_csv(outdir/'06_metas_projecoes.csv',metas,
       ['ano','n_contraprova','n_adequados','pct_adequados','alvo_pct','alvo_n_arredondado_cima',
        'conversoes_para_alvo','corte_empirico_contra','soma_lacunas_minima_grupo_prioritario','nota'])
    write_csv(outdir/'07_cenarios_ganhos_simulados.csv',cenarios,
       ['ano','ganho_hipotetico_acertos_por_aluno','adequados_simulados','pct_simulado','alvo_80_alcancado','tipo'])
    write_csv(outdir/'08_correlacoes_pareadas.csv',correlation,
       ['ano','n_pares','pearson_acertos_ref_contra','descricao'])
    # Skill aggregates, without conflating skill labels across instruments
    summary=[]
    for (ano,prova),p in ZIP_NAMES.items():
        off=next(d for d in school if d['ano']==ano and d['aplicacao']==prova)
        skillnames=sorted(set(x['habilidade'] for x in responses if x['ano']==ano and x['aplicacao']==prova),key=lambda h:int(h[1:]))
        offzip=paths[(ano,prova)]['zip']
        with zipfile.ZipFile(indir/offzip) as z:
            schoolrecord=read_csv_bytes(z.read(paths[(ano,prova)]['school_csv']))[0]
        for h in skillnames:
            rr=[x for x in responses if x['ano']==ano and x['aplicacao']==prova and x['habilidade']==h]
            a=sum(x['acertos'] for x in rr);total=sum(x['itens'] for x in rr)
            x=[x['percentual_acerto'] for x in rr];y=[x['adequado_caed'] for x in rr]
            corr=safe_corr(x,y)
            off_pct=int(schoolrecord[f'H {int(h[1:]):02d} (%)'])
            summary.append({'ano':ano,'aplicacao':prova,'habilidade':h,
             'respondentes':len(rr),'acertos':a,'itens':total,'erros':total-a,'taxa_acertos_recalculada':a/total,
             'taxa_acertos_oficial':off_pct/100,'correlacao_adequado_x_taxa_habilidade':corr,
             'aviso_correlacao':'Associação parte-todo: a classificação depende dos itens; NÃO é causalidade.',
             'arquivo_zip':offzip})
    write_csv(outdir/'09_sintese_habilidades.csv',summary,
        ['ano','aplicacao','habilidade','respondentes','acertos','itens','erros','taxa_acertos_recalculada',
         'taxa_acertos_oficial','correlacao_adequado_x_taxa_habilidade','aviso_correlacao','arquivo_zip'])
    write_csv(outdir/'10_auditoria_emparelhamento.csv',audit,
        ['ano','n_referencia','n_contraprova','n_pareados','so_referencia','so_contraprova','nomes_duplicados'])
    write_csv(outdir/'11_mapa_id_nome_RESTRITO.csv',[
         {'id_aluno':ids[(ano,n)],'nome':n,'ano':ano} for ano in ('1º ano','2º ano') for n in sorted(all_names[ano])],
        ['id_aluno','nome','ano'])
    # Precise machine-readable data dictionary
    dictionary=[
       ['ID','id_aluno','Identificador interno constante entre as formas. A tabela de correspondência nominal é RESTRITA.'],
       ['FONTE','aplicacao','Referencia ou contraprova: rótulo ASSUMIDO pelas exportações, sem metadado de teste.'],
       ['FONTE','arquivo_zip','Nome exato do ZIP fornecido na conversa.'],
       ['FONTE','arquivo_origem','CSV individual dentro do ZIP, preservado para rastreabilidade.'],
       ['ORIGINAL','nivel_caed','Defasagem / Intermediário / Adequado; classificação original.'],
       ['ORIGINAL','acertos e itens','Soma dos numeradores e denominadores de todas as habilidades da forma respectiva.'],
       ['CALCULADO','adequado_caed','1 se nivel_caed = Adequado; caso contrário 0.'],
       ['CALCULADO','taxa_acertos','acertos / itens; proporção 0-1.'],
       ['INFERIDO','corte_observado','Mínimo total de acertos entre os classificados Adequado naquela forma. NÃO é um ponto de corte CAEd publicado.'],
       ['CALCULADO','faltam_acertos_corte','max(0, corte_observado - acertos); aproximação aritmética.'],
       ['CALCULADO','pearson_acertos_ref_contra','Correlação de Pearson apenas entre estudantes identificados em ambas as formas, usando totais em 22 itens.'],
       ['CENARIO','ganho_hipotetico_acertos_por_aluno','Simulação +k respostas corretas para cada estudante, sem dados longitudinais ou probabilidade calibrada.'],
       ['CENARIO','soma_lacunas_minima_grupo_prioritario','Somatório das menores lacunas de acertos, para atingir 80% de Adequado, assumindo acertos independentes.'],
       ['ATENCAO','habilidade','Hxx deve ser interpretada dentro da sua forma; conjuntos têm números de H diferentes; equivalência entre versões não está documentada.'],
       ['ATENCAO','data_da_aplicacao','Não disponível. 30-07-2026 09h... no arquivo é data/hora de EXPORTAÇÃO.'],
       ['ATENCAO','percentual_aprendizagem_alfabetizacao','Não confundir com condição de leitor/não leitor de outro instrumento.'],
    ]
    write_csv(outdir/'12_dicionario_metodologia.csv', [dict(zip(['classe','campo','descricao'],x)) for x in dictionary],['classe','campo','descricao'])
    info={'instituicao':'Escola de Cidadania Airam Veras','inep':'23084995','componente':'Língua Portuguesa',
      'originais':[{'ano':ano,'rotulo_assumido':forma,**v} for (ano,forma),v in paths.items()],
      'contagens':audit,'correlacoes':correlation,'metas':metas,
      'hipotese_primaria':'Grupos (3)/(2) tratados como contraprova (1º)/(2º), somente para manter consistência do relatório anterior.',
      'privacidade':'Dados nominais de crianças: restritos à equipe escolar autorizada. CSVs anônimos não contêm nomes diretos.',
      'ressalvas':['Exportação não indica período real da prova.',
        'Percentuais de acertos e níveis de aprendizagem não substituem diagnósticos de fluência ou alfabetização.',
        'Cortes inferidos não são parâmetros oficiais.',
        'Habilidades Hxx de diferentes provas não devem ser consideradas equivalentes sem matriz de referência.',
        'Projeções de +k acertos são hipóteses de sensibilidade, não predições estatísticas calibradas.'],
      'arquivos_csv': sorted(x.name for x in outdir.glob('*.csv'))}
    (outdir/'13_manifesto_proveniencia.json').write_text(json.dumps(info,indent=2,ensure_ascii=False),encoding='utf-8')
    (outdir/'LEIA-ME.txt').write_text('''DATASET AUDITÁVEL — ESCOLA DE CIDADANIA AIRAM VERAS, CRATEÚS/CE — CAEd 2026
==========================================================
Registros: 24 e 24 no 1º ano; 26 e 28 no 2º ano. Pareamentos exatos: 24 e 25.
Arquivo de referência e de contraprova: interpretação assumida a partir dos
arquivos exportados; não constam rótulos de aplicação nem datas das provas nos CSVs.
Fonte: quatro ZIPs CAEd anexados pelo usuário. O manifesto documenta os CSVs originais.

01: Base de alunos e avaliações (nominal restrita e variante anonimizada).
02: Respostas/acertos por habilidade, formato longo, anonimizado.
03: Indicadores originais agregados da escola.
04: Indicadores originais agregados da turma.
05: Comparação pareada entre provas; bases anônima e nominal restrita.
06: Metas/necessidades aritméticas para atingir 80% por turma.
07: Cenários de ganho +0 a +6 acertos por estudante (SIMULAÇÕES, NÃO PREVISÕES).
08: Correlações pareadas observadas; somente estudantes comuns.
09: Síntese de habilidades com taxas próprias e oficiais.
10: Auditoria de quantidade de estudantes comparáveis.
11: Dicionário de pseudônimos e nomes — RESTRITO.
12: Dicionário de variáveis, premissas e limitações.
13: Metadados e linhagem.

Fórmulas: taxa = acertos/itens; adequado=1 se nível CAEd é Adequado;
meta mínima=ARREDONDAR.PARA.CIMA(0,8*N); conversões=meta-adequados;
lacuna individual=max(0, mínimo escore no grupo classificado Adequado - acertos).
Esse mínimo observado varia entre formas e não foi publicado como corte oficial.
Avisos: identificadores H01, H02... não garantem equivalência entre provas.
Não se conclui causalidade de correlações. Diferentes pessoas no 2º ano e
poucos dados impedem chamar as simulações de predições calibradas.

PRIVACIDADE: não divulgar arquivos RESTRITO nem o mapeamento ID/nome publicamente.
O arquivo de respostas anonimizadas permite análise sem divulgar nomes diretos.
''',encoding='utf-8')
    print(json.dumps({'contagens':audit,'correlacoes':correlation,'metas':metas, 'habilidades':len(summary),'linhas_respostas':len(responses),'linhas_alunos':len(records)},ensure_ascii=False,indent=2))
    return info

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--input-dir',default='/mnt/data');ap.add_argument('--out-dir',default='/mnt/data/dataset_CAEd')
    a=ap.parse_args();run(a.input_dir,a.out_dir)
