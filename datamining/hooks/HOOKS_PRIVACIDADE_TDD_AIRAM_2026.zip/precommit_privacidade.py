"""Bloqueio conservador de caminhos para Git pre-commit em projetos Airam Veras.

A checagem é baseada em caminhos/nomes, NÃO é detector completo de dados pessoais.
Execução local: python hooks/precommit_privacidade.py
Instalação deliberada: git config core.hooksPath hooks
"""
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import PurePosixPath

EXCLUDED_PARTS = {"restrito", ".venv", "node_modules", "__pycache__", ".git", "originais"}
SENSITIVE_EXTENSIONS = {".csv", ".tsv", ".xlsx", ".xls", ".zip", ".sqlite", ".db", ".parquet",
                        ".key", ".pem", ".p12", ".pfx"}
SENSITIVE_MARKERS = ("nominal", "estudante", "aluno", "paciente", "senha", "secret",
                     "token", "credencial", "private", "dados_brutos")


def validate_staged_paths(paths: list[str]) -> list[str]:
    """Devolve justificativas, sem acessar conteúdos ou nomes de alunos."""
    errors = []
    for original in paths:
        path = original.replace("\\", "/").strip()
        p = PurePosixPath(path)
        parts = tuple(part.casefold() for part in p.parts)
        base = p.name.casefold()
        reason = None
        if not path or path.startswith("/") or re.match(r"^[A-Za-z]:", path):
            reason = "caminho não relativo ao projeto"
        elif any(part == ".." for part in parts):
            reason = "travessia de diretórios"
        elif any(part in EXCLUDED_PARTS for part in parts):
            reason = "diretório restrito, ambiente ou fonte bruta"
        elif base.startswith(".env") or any(mark in base for mark in SENSITIVE_MARKERS):
            reason = "nome possivelmente sensível"
        elif p.suffix.casefold() in SENSITIVE_EXTENSIONS:
            reason = "tipo de arquivo de dados/binário não admitido no repositório"
        if reason:
            errors.append(f"{reason}: {original}")
    return errors


def main() -> int:
    cp = subprocess.run(
        ["git", "diff", "--cached", "--name-only", "-z"],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    if cp.returncode != 0:
        print("Erro ao obter arquivos preparados no Git.", file=sys.stderr)
        return 2
    paths = [p.decode("utf-8", "replace") for p in cp.stdout.split(b"\0") if p]
    problems = validate_staged_paths(paths)
    for p in problems:
        print("BLOQUEADO: " + p, file=sys.stderr)
    if problems:
        print("Retire os itens do staging e revise a política de acesso.", file=sys.stderr)
        return 1
    print("Checagem de caminhos concluída; revisão humana de conteúdo continua obrigatória.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
