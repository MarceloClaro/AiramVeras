# Hook Git Airam Veras — política conservadora
Instalação manual **no repositório de código local**:
1. Coloque `precommit_privacidade.py` dentro de `datamining/hooks/`.
2. Renomeie/copie `precommit_privacidade.py` como `pre-commit` (sem extensão),
   ou crie wrapper executável que invoque `python hooks/precommit_privacidade.py`.
3. Configure `git config core.hooksPath hooks` somente após verificar o Git local.
4. Execute `python -m unittest -v tests/test_precommit_privacidade.py`.
5. Execute a suíte de regressão do projeto completo antes de integrar.

O hook bloqueia por padrões de **caminho/nome/extensão**: `restrito`,
fontes brutas, planilhas, CSVs, bancos, chaves e credenciais.
Não examina dados pessoais dentro de código permitido. Exige revisão humana
e não é garantia de anonimização. Este pacote foi validado com 8 testes
locais isolados, não instalado no ambiente Windows do usuário.
