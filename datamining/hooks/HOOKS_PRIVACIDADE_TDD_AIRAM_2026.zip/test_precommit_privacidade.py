import unittest
from precommit_privacidade import validate_staged_paths

class TestProtecaoGit(unittest.TestCase):
    def test_bloqueia_dados_nominais(self):
        self.assertTrue(validate_staged_paths(["restrito/t02/estudantes.csv"]))

    def test_bloqueia_planilha_e_base_de_dados(self):
        self.assertEqual(len(validate_staged_paths(["reports/nominal.xlsx", "dados/bncc.sqlite"])), 2)

    def test_bloqueia_segredos(self):
        self.assertTrue(validate_staged_paths(["config/credenciais.json", ".env"]))

    def test_bloqueia_pasta_ambiente(self):
        self.assertTrue(validate_staged_paths([".venv/Lib/site-packages/lib.py"]))

    def test_bloqueia_caminho_windows_para_diretorio_restrito(self):
        self.assertTrue(validate_staged_paths([r"restrito\codigo.py"]))

    def test_permite_caminho_windows_documental(self):
        self.assertEqual(validate_staged_paths([r"docs\spec.md"]), [])

    def test_rejeita_caminho_traversal(self):
        self.assertTrue(validate_staged_paths(["../publicado.py"]))

    def test_permite_documentacao_e_codigo(self):
        self.assertEqual(validate_staged_paths(["README.md", "airam/metricas.py",
                                                 "tests/test_metricas.py", "specs/SPEC-AIRAM-002.md"]), [])

if __name__ == "__main__":
    unittest.main()
