# Escola Cidadania Airam Veras
## Relatório técnico-pedagógico — CAEd Ciclo I/2026, BNCC e metas de aprendizagem

**Emissão:** 23/10/2026. **Público:** gestão e equipe pedagógica.
**Escopo:** 1º ao 5º ano, Leitura e Matemática. Produto **agregado, sem identificação individual**.
**Fontes:** checkpoints T04–T09 já existentes no projeto datamining; versões e SHA256 preservados.

### 1. Contraprova estatística

A etapa T05 registra a conferência de **4.618 observações** em **679 grupos**, com resultado `coincide=true`.
Foram conferidos **407 percentuais** do portal; **406** foram reproduzidos pela regra de arredondamento
*half-up* e **1** exigiu ressalva sobre empate/quantização. Não houve divergência de coerência nas
442 verificações de contagens. O percentual publicado pelo portal deve permanecer intacto:
uma diferença de arredondamento não autoriza reescrever o resultado oficial.

### 2. Meta A: 80% dos estudantes avaliados no nível adequado original CAEd

| Ano | Componente | Adequados/avaliados | Taxa original | Alvo de alunos | Entradas líquidas necessárias |
|---|---|---|---|---|---|
| 1º | Leitura | 10/24 | 41.7% | 20 | 10 |
| 1º | Matematica | 11/24 | 45.8% | 20 | 9 |
| 2º | Leitura | 18/28 | 64.3% | 23 | 5 |
| 2º | Matematica | 15/28 | 53.6% | 23 | 8 |
| 3º | Leitura | 18/24 | 75.0% | 20 | 2 |
| 3º | Matematica | 17/24 | 70.8% | 20 | 3 |
| 4º | Leitura | 33/42 | 78.6% | 34 | 1 |
| 4º | Matematica | 16/42 | 38.1% | 34 | 18 |
| 5º | Leitura | 45/53 | 84.9% | 43 | 0 |
| 5º | Matematica | 35/54 | 64.8% | 44 | 9 |

**Atenção:** Meta A não é 80% de acertos. A Meta B, separadamente, exige 80% dos
acertos/oportunidades de cada estudante; não se deve converter uma em outra sem regra oficial.

### 3. Habilidades prioritárias por ano e componente

A lista seguinte ordena **taxas observadas de acertos por posição**; é priorização para sondagem,
não prova de deficiência individual nem de causalidade. Os vínculos BNCC são associações documentais
e podem conter ressalvas de equivalência semântica.

**4º ano — Matematica**

  - H 10: **35.7%**, 30/84 acertos/oportunidades; Interpretar dados estatísticos dispostos em tabelas de dupla entrada. Referências BNCC: EF03MA27.
  - H 06: **36.9%**, 31/84 acertos/oportunidades; Interpretar movimentação de pessoas, animais ou objetos no espaço, considerando mais de um ponto de referência e noções de orientação, indicando sua posição após finalizada a movimentação. Referências BNCC: EF02MA12.
  - H 15: **48.8%**, 41/84 acertos/oportunidades; Utilizar a operação de multiplicação entre números naturais, formados por até quatro algarismos, envolvendo o significado de adição de parcelas iguais, de organização retangular ou de proporcionalidade, na resolução de problema. Referências BNCC: EF02MA07, EF03MA07, EF04MA06.
  - H 03: **50.0%**, 21/42 acertos/oportunidades; Efetuar a operação de subtração entre números naturais formados por até quatro algarismos. Referências BNCC: EF03MA05.

**1º ano — Leitura**

  - H 04: **50.0%**, 36/72 acertos/oportunidades; Identificar a correta segmentação das palavras na escrita. Referências BNCC: EF01LP12.
  - H 07: **60.4%**, 29/48 acertos/oportunidades; Ler palavras formadas exclusivamente por sílabas canônicas. Referências BNCC: EF02LP04.
  - H 05: **62.5%**, 45/72 acertos/oportunidades; Identificar rimas. Referências BNCC: EF12LP19.
  - H 02: **75.0%**, 36/48 acertos/oportunidades; Reconhecer letras do alfabeto. Referências BNCC: EF01LP10.

**1º ano — Matematica**

  - H 03: **70.8%**, 51/72 acertos/oportunidades; Classificar objetos segundo atributos de cor, forma ou medida. Referências BNCC: EF01MA09.
  - H 02: **77.8%**, 56/72 acertos/oportunidades; Comparar quantidades de objetos de coleções, contendo até 20 elementos cada, com suporte de imagens, indicando qual tem mais, qual tem menos ou quais têm a mesma quantidade. Referências BNCC: EF01MA03.
  - H 04: **79.2%**, 57/72 acertos/oportunidades; Interpretar localização de pessoas, animais ou objetos no espaço, considerando um ponto de referência e noções de orientação (à direita, à esquerda, em frente, atrás, em cima ou embaixo). Referências BNCC: EF01MA12.
  - H 05: **100.0%**, 72/72 acertos/oportunidades; Reconhecer figura geométrica espacial (cone, cilindro, esfera ou bloco retangular) em objetos do mundo físico, pela sua forma. Referências BNCC: EF01MA13.

**2º ano — Matematica**

  - H 06: **41.1%**, 23/56 acertos/oportunidades; Comparar quantidades de objetos de duas coleções, contendo até 50 elementos cada, com suporte de imagens, indicando qual tem mais objetos e quantos a mais, qual tem menos objetos e quantos a menos ou se têm a mesma quantidade de objetos e qual é essa quantidade. Referências BNCC: EF01MA03, EF02MA03.
  - H 07: **55.4%**, 31/56 acertos/oportunidades; Comparar números naturais formados por até três algarismos, indicando o menor, o maior, a ordenação crescente ou a decrescente deles. Referências BNCC: EF01MA05, EF02MA01.
  - H 09: **62.5%**, 35/56 acertos/oportunidades; Utilizar a operação de subtração entre números naturais, formados por até três algarismos, envolvendo o significado de separar ou de retirar, com ou sem suporte de imagens, na resolução de problema. Referências BNCC: EF01MA08, EF02MA06.
  - H 04: **69.6%**, 39/56 acertos/oportunidades; Identificar dados estatísticos dispostos em tabelas simples, em gráficos de colunas ou de barras simples. Referências BNCC: EF01MA21.

**3º ano — Matematica**

  - H 02: **47.9%**, 23/48 acertos/oportunidades; Interpretar localização de pessoas, animais ou objetos no espaço, considerando um ou mais de um ponto de referência e noções de orientação (à direita, à esquerda, em frente, atrás, em cima e/ou embaixo). Referências BNCC: EF01MA12, EF02MA12.
  - H 06: **75.0%**, 36/48 acertos/oportunidades; Interpretar dados estatísticos dispostos em tabelas simples, em gráficos de colunas ou de barras simples. Referências BNCC: EF02MA22.
  - H 09: **77.1%**, 37/48 acertos/oportunidades; Utilizar a operação de adição entre números naturais, formados por até quatro algarismos, envolvendo o significado de juntar ou de acrescentar, na resolução de problema. Referências BNCC: EF02MA06, EF03MA06.
  - H 10: **77.1%**, 37/48 acertos/oportunidades; Utilizar a operação de subtração entre números naturais, formados por até quatro algarismos, envolvendo o significado de separar, de retirar, de comparar ou de completar, na resolução de problema. Referências BNCC: EF02MA06, EF03MA06.

**5º ano — Matematica**

  - H 15: **31.5%**, 17/54 acertos/oportunidades; Medir área de figuras planas, desenhadas em malha quadriculada, cujos lados se posicionam sobre linhas de grade da malha. Referências BNCC: EF04MA21.
  - H 05: **33.3%**, 18/54 acertos/oportunidades; Interpretar dados estatísticos dispostos em tabelas de dupla entrada. Referências BNCC: EF03MA27.
  - H 03: **44.4%**, 24/54 acertos/oportunidades; Determinar termos ausentes em sequências de números naturais, formados por até quatro algarismos, resultantes de adições ou de subtrações sucessivas por um mesmo número. Referências BNCC: EF03MA10.
  - H 14: **46.3%**, 25/54 acertos/oportunidades; Reconhecer ângulos retos e ângulos não retos em figuras geométricas planas. Referências BNCC: EF04MA18.

**4º ano — Leitura**

  - H 06: **48.8%**, 41/84 acertos/oportunidades; Identificar variações de sons de grafema no caso de correspondências irregulares entre grafemas e fonemas (sons do z – s/z/x; sons do s – ss/c/ç/sc/sç/x/xc). Referências BNCC: EF05LP01.
  - H 04: **54.8%**, 23/42 acertos/oportunidades; Identificar variações de sons de grafema no caso de correspondências regulares contextuais entre grafemas e fonemas (c/qu; g/gu; r/rr; s/ss). Referências BNCC: EF05LP01.
  - H 10: **56.0%**, 47/84 acertos/oportunidades; Reconhecer o efeito de sentido produzido pelos pontos de exclamação e interrogação. Referências BNCC: EF01LP14.
  - H 05: **57.1%**, 48/84 acertos/oportunidades; Identificar variações de sons de grafema no caso de correspondências irregulares entre grafemas e fonemas (j/g; c antes de e/i; sons do x – x/ch). Referências BNCC: EF05LP01.

**2º ano — Leitura**

  - H 01: **35.7%**, 20/56 acertos/oportunidades; Reconhecer o local de inserção de uma palavra na ordem alfabética. Referências BNCC: EF01LP10.
  - H 07: **48.2%**, 27/56 acertos/oportunidades; Inferir informação em texto que articula linguagem verbal e não verbal. Referências BNCC: EF15LP14.
  - H 08: **57.1%**, 32/56 acertos/oportunidades; Reconhecer o gênero de um texto que circula no campo de atuação da vida cotidiana. Referências BNCC: EF15LP02.
  - H 02: **71.4%**, 40/56 acertos/oportunidades; Identificar rimas. Referências BNCC: EF12LP19.

**3º ano — Leitura**

  - H 05: **66.7%**, 32/48 acertos/oportunidades; Localizar informações explícitas em textos, recuperadas por meio de paráfrase. Referências BNCC: EF15LP03.
  - H 03: **68.8%**, 33/48 acertos/oportunidades; Inferir informação em texto que articula linguagem verbal e não verbal. Referências BNCC: EF15LP14.
  - H 09: **70.8%**, 34/48 acertos/oportunidades; Reconhecer o efeito de sentido produzido pelo uso de recursos expressivos gráfico-visuais em tirinhas e histórias em quadrinhos. Referências BNCC: EF15LP14.
  - H 07: **77.1%**, 37/48 acertos/oportunidades; Inferir o sentido de palavra ou expressão idiomática própria da linguagem informal, com base em pistas co-textuais (sinonímia, palavra do mesmo campo semântico). Referências BNCC: EF35LP05.

**5º ano — Leitura**

  - H 12: **25.5%**, 27/106 acertos/oportunidades; Inferir, em textos de nível 2, o sentido de palavras ou expressões não coloquiais, com apoio de pistas co-textuais (sinonímia, antonímia, palavras do mesmo campo semêntico e outras sinalizações). Referências BNCC: EF35LP05.
  - H 14: **67.0%**, 71/106 acertos/oportunidades; Identificar a finalidade de textos dos campos de atuação da vida cotidiana, jornalístico midiático ou de estudos e pesquisas pela compreensão global. Referências BNCC: EF15LP01.
  - H 10: **67.9%**, 36/53 acertos/oportunidades; Reconhecer relações lógico-discursivas marcadas por advérbios e expressões adverbiais de tempo em textos de diferentes gêneros. Referências BNCC: EF05LP07.
  - H 08: **75.5%**, 80/106 acertos/oportunidades; Reconhecer o narrador em narrativas ficcionais, quando se trata do narrador em primeira pessoa. Referências BNCC: EF35LP29.

### 4. Clusters e perfis pedagógicos

- No **4º ano — Leitura**, o checkpoint T08 aceitou **2 clusters exploratórios estáveis**,
  com grupos de **11 e 31 estudantes**, após controles de estabilidade. Isso ainda não é
  diagnóstico pedagógico nem validação externa.
- Nos demais nove instrumentos Leitura/Matemática, os critérios de liberação do agrupamento
  estatístico **não foram satisfeitos**. O resultado correto é registrar a falta de clusters
  estáveis, **não forçar um número de grupos**.
- Há, em contrapartida, perfis **determinísticos por regra**, por exemplo: estudante que
  alcança ou não a Meta B. Esses perfis podem apoiar atendimento diferenciado, mas
  não devem ser anunciados como clusters de aprendizado de máquina.
- Grupos com menos de cinco integrantes devem ser suprimidos nas saídas agregadas.
  Os dados individualizados, quando necessários, devem continuar exclusivamente na área
  restrita, com controle de acesso por função.

### 5. Correlações e grafo/convolução curricular

A etapa T06 contém **428 associações** com famílias de hipóteses, testes por permutação e
ajustes de multiplicidade. Relações entre leitura, matemática, escrita e fluência são
**associações observacionais**, não demonstrações de que reforçar uma habilidade causa
melhora em outra. A aba `Correlacoes` da planilha traz 80 associações com resultados
disponíveis, incluindo coeficiente, N e `q` (FDR global).

A etapa T07 registra grafos entre posições avaliadas, descritores CAEd e códigos BNCC.
A propagação por matriz/grafo é útil para organizar a progressão curricular, mas **não deve
ser tratada como convolução preditiva validada** na ausência de amostras longitudinais.

### 6. Cenários condicionais, não previsão temporal

A etapa T09 reúne **96 cenários** entre escola e turma com hipóteses de entrada/saída
de estudantes da categoria original e ganho/perda de acertos. A planilha mostra os
40 cenários do nível escola. Com apenas um ciclo temporal confirmado, não existe
modelo longitudinal calibrado para prever com confiança o Ciclo II/III.

**Exemplo — 4º ano Matemática:** são necessárias **18 entradas líquidas** no nível adequado
(original CAEd), supondo 42 avaliados e nenhuma saída da categoria. Um cenário com ganho
de um estudante produz 17/42, ainda distante dos 34 necessários. A classificação
só pode ser confirmada em nova avaliação conforme a regra do CAEd.

### 7. Intervenção pedagógica por ciclo curto

**Semanas 1–2:** aplicar sondagens inéditas por habilidade, conferir os cadernos e erros
por tipo, distinguir ausência de tentativa e erro efetivo, agrupar provisoriamente por
necessidade observada e registrar linha de base.

**Semanas 3–4:** executar sequências didáticas explícitas e flexíveis: modelagem do
procedimento, prática guiada, tarefas novas, recuperação da evidência e devolutiva
formativa. Priorizar leitura de tabelas, orientação espacial, multiplicação/subtração e
leitura inicial onde indicado pelos dados.

**Semana 5:** reaplicar instrumento paralelo com itens comparáveis, registrar acertos e
oportunidades, verificar estabilidade e comparar dentro da mesma turma. Não usar o
resultado simulado como se fosse nota observada.

**Semanas 6–8:** decidir continuidade/ajuste por resposta pedagógica, com validação
humana da coordenação e dos docentes, plano individual apenas onde houver dados suficientes.

### 8. Limitações e confidencialidade

Não utilizar nome isolado como chave longitudinal; preservar pseudonimização local.
Não publicar clusters pequenos, classificações nominais, laudos ou matriz de intervenção.
Toda ação dirigida a crianças precisa de avaliação contextual docente, e o teste
estatístico não substitui julgamento pedagógico. O relatório contém somente agregados.

### Referências de origem e proveniência
- CAEd/BNCC, T04: https://drive.google.com/file/d/1n8F2kDfidB84QrJTtrHgbhUHL2G311qV/view
- Contraprova/metas, T05: https://drive.google.com/file/d/16eVTPVA7dcw777b6BaXqoDEoWD9_mfgi/view
- Correlações, T06: https://drive.google.com/file/d/1XW2ivmH47lsMu0cive8gtjfZ9oqkiigi/view
- Grafos, T07: https://drive.google.com/file/d/1919ih1qxQAtE_WyxA0gZJjsNiUQa2p9u/view
- Perfis/clusters, T08: https://drive.google.com/file/d/1hCKZOAEqAUoLbxcsWGqVBkF86XIOQbx9/view
- Cenários, T09: https://drive.google.com/file/d/1cnq4H5b9kIRERW-8E9Hkx0b7CRY36iCf/view
- BNCC: https://github.com/MarceloClaro/bncc-dados
