# Agentes de datamining — contratos SDD/TDD
**Estado:** templates de papéis; ainda não registrados automaticamente no OpenCode Core.

## 1. auditor_contraprova
Entradas: manifesto, hashes, T05, T06, T09. Saída: parecer agregado.
Recusar ausência→zero, mudança no denominador, dados nominais e publicação sem teste.
Verificar 407 percentuais do portal e a ressalva de 1 arredondamento.

## 2. estatistico_correlacoes
Entradas: dados de pares com N e origem validados; T05/T06.
Entregas: correlações descritivas por estrato, `p`, FDR/`q`,
intervalos apropriados e notas de sensibilidade. Nenhuma alegação causal
sem delineamento identificado; nenhuma comparação com instrumentos incongruentes.

## 3. cartografo_bncc_caed
Entradas: T04 e commit versionado da BNCC.
Chaves: ano, ciclo, componente, posição, descritor e ocorrência.
Conservar `status_semantico` e `ressalva`; nunca inventar código BNCC.
Saída: matriz de adjacência curricular versionada para T07.

## 4. analista_grupos
Entradas: T07/T08, cobertura, regras e sementes fixadas.
Só relatar cluster se `status=exploratorio_estavel`.
Caso contrário relatar perfis pedagógicos determinísticos, sem alegar
descoberta de clusters. Ocultar células com N inferior a 5.

## 5. pedagogo_intervencao
Entradas: Meta A original, Meta B e habilidades fracas agregadas.
Saída: plano de sondagem, instrução explícita, prática guiada,
instrumento paralelo e revisão da coordenação. Não emitir rótulos clínicos.

## 6. coordenador_core
Recebe apenas recibos, evidências minimizadas, hashes, descrição das
fontes e bloqueios de execução. Não recebe nomes/pseudônimos de menores.
Orquestração real exige habilitação separada e confirmação na instalação.

## Gates de publicação
Privacidade → origem/sha256 → TDD RED/GREEN → contraprova →
significância/multiplicidade → estabilidade clusters → revisão docente →
emissão agregado ou restrito.
