# SPEC-AIRAM-002 — Consolidação CAEd + BNCC no Google Drive
> Referência: SPEC-AIRAM-001. Artefato aditivo, não substitutivo. Data 23/10/2026.

## Objetivo
Organizar dados CAEd/CNCA, matrizes BNCC, contraprova estatística,
grafo curricular, correlatos, perfis/agrupamentos e cenários de Meta A e B na
pasta Airam veras (Drive ID 1DqldZhh3agGr3Nwc6CTuord7gIm8xkHP),
com rastreabilidade, revisão humana e privacidade infantojuvenil.

## Diretórios canônicos
- `resultados-caed-ciclo-i-2026/`: originais, manifesto, 54 CSVs e conferência.
- `bncc-dados/`: dataset versionado. Não renomear nem reescrever código.
- `datamining/airam`: módulos, TDD e CLI.
- `datamining/tests`: testes T01–T10 existentes; manter legíveis.
- `datamining/specs`: SPEC-AIRAM-001 + esta extensão.
- `datamining/docs`: dicionários e esquemas T02–T09.
- `datamining/evidencias`: recibos de testes + hashes.
- `datamining/restrito`: checkpoints nominais, segregados.
- `datamining/agents`: contratos de papéis dos agentes.
- `datamining/hooks`: gate Git pré-commit e testes de guarda.
- `datamining/reports/diagnosticos_2026`: relatório pedagógico agregado.
- `00_ORGANIZACAO/04_Relatorios/Paineis_2026`: planilha gerencial agregada.

## Contratos e indicadores
- Meta A = `ceil(0.80*N_avaliados) - N_adequados_originais`, truncado em zero.
- Meta B = `ceil(0.80*oportunidades_i) - acertos_i`, truncado em zero;
  só quando o número de oportunidades for observado.
- Grupo não observado NÃO vira zero. Zero efetivo deve permanecer zero.
- Identidade de estudantes somente na área `restrito`, não sincronizar com Core remoto.
- Formação de clusters: não impor `k` se as métricas de estabilidade não aprovarem.
  Resultados T08 aceitos apenas onde o gate registrou `exploratorio_estavel`.
- Grafo CAEd–BNCC: chaves `(ano, ciclo, componente, descritor/posição, ocorrência, versão)`;
  um código não implica equivalência pedagógica plena.
- Correlações: amostras pareadas, unidade consistente, N, teste apropriado,
  efeito, permutação, FDR e correções de múltiplos testes.
- Projeções: cenários de sensibilidade são condicionais; não anunciar como
  previsão temporal sem dados longitudinais e validação fora da amostra.

## Sequência SDD → TDD → contraprova
1. Abrir SPEC-AIRAM-001 e dicionários T04–T09; registrar hash das fontes.
2. Criar teste RED para o novo comportamento; registrar saída e motivo.
3. Implementar apenas o mínimo; executar GREEN e suíte completa.
4. Revisão independente de código/dados, negativos e controle de privacidade.
5. Contraprova com Fraction/contagens exatas; intervalos de arredondamento.
6. Atualizar recibos TNN com SHA256, datas e parâmetros.
7. Gerar relatório agregado, preservar saídas nominais somente em `restrito`.
8. Validação pedagógica manual de interpretação e das prioridades.
9. T10: executar, revisar, registrar pacote final; NÃO marcar concluída apenas
   porque um teste de outro incremento passou.

## Agentes (somente papéis; requer instalação controlada)
- Estatístico: gera indicadores, pares, FDR, cenários e incerteza.
- Auditor: valida SHA256, separação de fontes, contraprovas e TDD.
- BNCC: junta descritores com códigos oficiais sem alucinar equivalências.
- Planejamento: traduz evidências agregadas em propostas de sondagem/intervenção.
- Core: orquestra apenas recibos e informações minimizadas; inferência individual
  remota bloqueada até autorização e contrato específico de privacidade.

## Testes mínimos de aceite
- Checksum mudou? Reprovar.
- Ausência vira zero? Reprovar.
- Meta A inferida de acerto Meta B? Reprovar.
- Célula CAEd sem ano/ciclo/versão? Reprovar.
- `q` ausente em inferência múltipla? Reprovar.
- Cluster não estável anunciado como verdadeiro? Reprovar.
- Saída nominal na área pública? Reprovar.
- Previsão temporal sem múltiplos ciclos validados? Reprovar.
- Hook rejeita caminhos Windows/Linux, segredos e dados privados.
- Teste de ponta a ponta deve registrar denominadores e contraprovas.

## Estado de execução
O relatório agregado e planilha foram gerados a partir dos checkpoints existentes
e não substituem uma nova execução completa da suíte local do Windows/OpenCode.
A integração real com o OpenCode Core deve ser confirmada no ambiente do usuário.
